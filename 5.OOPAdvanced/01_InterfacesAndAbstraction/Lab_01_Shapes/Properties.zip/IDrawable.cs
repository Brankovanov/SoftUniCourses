﻿
    //IDrawable interface parent to circle and rectangle class.
    public interface IDrawable
    {
        void Draw();
    }
