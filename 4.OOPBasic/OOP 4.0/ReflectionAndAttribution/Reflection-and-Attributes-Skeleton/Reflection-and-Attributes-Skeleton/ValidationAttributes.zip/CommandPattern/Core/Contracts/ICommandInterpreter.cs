﻿namespace CommandPattern.Core.Contracts
{
    public interface ICommandInterpreter
    {
        void Read(string args);
    }
}
