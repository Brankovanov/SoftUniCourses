﻿using CommandPattern.Core.Contracts;
using System;

namespace CommandPattern
{
    public class Commands : ICommand

    {
        public void Execute(string[] args)
        {
            switch (args[0])
            {
                case "Hello":
                   Console.WriteLine( $"Hello, {args[0]}");
                    break;
                case "Exit":
                    Environment.Exit(1);
                    break;
                default:
                    break;
            }

        }
    }
}
