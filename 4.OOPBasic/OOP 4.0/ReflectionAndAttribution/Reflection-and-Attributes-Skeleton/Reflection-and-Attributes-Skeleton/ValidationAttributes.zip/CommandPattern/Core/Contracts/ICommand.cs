﻿namespace CommandPattern.Core.Contracts
{
    public interface ICommand
    {
       void Execute(string[] args);
    }
}
